package com.example.lab_game.data


data class QuizQuestion(
    val imageRes: Int,
    val question: String,
    val options: List<String>,
    val answerIndex: Int,
    val keyFact: String
)

// Example Roman Heritage questions, extend as needed
val romanQuestions = listOf(
    QuizQuestion(
        imageRes = R.drawable.el_jem,
        question = "What is the name of this monument?",
        options = listOf("El Jem Amphitheater", "Dougga Theater", "Carthage Colosseum", "Thuburbo Majus"),
        answerIndex = 0,
        keyFact = "El Jem is the 3rd largest Roman amphitheater in the world."
    ),
    QuizQuestion(
        imageRes = R.drawable.dougga,
        question = "Which Roman city is shown?",
        options = listOf("El Djem", "Thuburbo Majus", "Dougga", "Uthina"),
        answerIndex = 2,
        keyFact = "Dougga is a UNESCO World Heritage site and was a major city in Roman Africa."
    ),
    QuizQuestion(
        imageRes = R.drawable.carthage,
        question = "This site belonged to which ancient city?",
        options = listOf("Leptis Magna", "Carthage", "Sbeitla", "Timgad"),
        answerIndex = 1,
        keyFact = "Carthage was a major Punic then Roman city and capital in North Africa."
    ),
    QuizQuestion(
        imageRes = R.drawable.carthage,
        question = "This site belonged to which ancient city?",
        options = listOf("Leptis Magna", "Carthage", "Sbeitla", "Timgad"),
        answerIndex = 1,
        keyFact = "Carthage was a major Punic then Roman city and capital in North Africa."
    ),
    QuizQuestion(
        imageRes = R.drawable.carthage,
        question = "This site belonged to which ancient city?",
        options = listOf("Leptis Magna", "Carthage", "Sbeitla", "Timgad"),
        answerIndex = 1,
        keyFact = "Carthage was a major Punic then Roman city and capital in North Africa."
    ),
    QuizQuestion(
        imageRes = R.drawable.carthage,
        question = "This site belonged to which ancient city?",
        options = listOf("Leptis Magna", "Carthage", "Sbeitla", "Timgad"),
        answerIndex = 1,
        keyFact = "Carthage was a major Punic then Roman city and capital in North Africa."
    ),
    QuizQuestion(
        imageRes = R.drawable.carthage,
        question = "This site belonged to which ancient city?",
        options = listOf("Leptis Magna", "Carthage", "Sbeitla", "Timgad"),
        answerIndex = 1,
        keyFact = "Carthage was a major Punic then Roman city and capital in North Africa."
    ),
    QuizQuestion(
        imageRes = R.drawable.carthage,
        question = "This site belonged to which ancient city?",
        options = listOf("Leptis Magna", "Carthage", "Sbeitla", "Timgad"),
        answerIndex = 1,
        keyFact = "Carthage was a major Punic then Roman city and capital in North Africa."
    ),
    QuizQuestion(
        imageRes = R.drawable.carthage,
        question = "This site belonged to which ancient city?",
        options = listOf("Leptis Magna", "Carthage", "Sbeitla", "Timgad"),
        answerIndex = 1,
        keyFact = "Carthage was a major Punic then Roman city and capital in North Africa."
    ),
    QuizQuestion(
        imageRes = R.drawable.carthage,
        question = "This site belonged to which ancient city?",
        options = listOf("Leptis Magna", "Carthage", "Sbeitla", "Timgad"),
        answerIndex = 1,
        keyFact = "Carthage was a major Punic then Roman city and capital in North Africa."
    )

    // Add at least 10-15 following this structure.
)