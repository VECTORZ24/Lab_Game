package com.example.lab_game.model

enum class GameCategory(val displayName: String) {
    RomanHeritage("Roman Heritage"),
    IslamicHeritage("Islamic Heritage"),
    PunicPreRoman("Punic & Pre-Roman"),
    ModernHeritage("Modern Heritage"),
    NaturalMixedSites("Natural & Mixed Sites"),
    Cities("Cities")
}