package com.example.lab_game.tunisheritagegame

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TunisiaHeritageQuestTheme {
                TunisiaHeritageNavGraph()
            }
        }
    }
}