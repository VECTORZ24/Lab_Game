// navigation/NavGraph.kt
package com.example.lab_game.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.lab_game.ui.*
import com.example.lab_game.ui.screens.CategorySelectionScreen
import com.example.lab_game.ui.screens.MainMenuScreen
import com.example.lab_game.ui.screens.QuizScreen
import com.example.lab_game.ui.screens.SplashScreen

object Routes {
    const val Splash = "splash"
    const val MainMenu = "main_menu"
    const val CategorySelection = "category_selection"
    const val DifficultySettings = "difficulty_settings"
    const val Quiz = "quiz"
    const val Results = "results"
}

@Composable
fun HeritageNavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Routes.Splash) {
        composable(Routes.Splash) { SplashScreen(navController) }
        composable(Routes.MainMenu) { MainMenuScreen(navController) }
        composable(Routes.CategorySelection) { CategorySelectionScreen(navController) }
        composable(Routes.DifficultySettings) { DifficultySettingsScreen(navController) }
        composable(Routes.Quiz) { QuizScreen(navController) }
        composable(Routes.Results) { ResultScreen(navController) }
    }
}