package com.example.lab_game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun CategorySelectionScreen(navController: NavController) {
    Box(Modifier.fillMaxSize().background(Color(0xFFEADABA))) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Choose a Category", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { navController.navigate("difficulty") },
                modifier = Modifier.fillMaxWidth(0.7f)
            ) { Text("Roman Heritage") }
            // Add other categories if needed, disable those not implemented
        }
    }
}