package com.example.lab_game.model

enum class Difficulty(val displayName: String) {
    Easy("Easy"),
    Medium("Medium"),
    Hard("Hard")
}