package com.example.lab_game.model

data class Question(
    val id: Int,
    val category: GameCategory,
    val difficulty: Difficulty,
    val imageResId: Int, // Drawable resource reference
    val questionText: String,
    val options: List<String>,
    val correctAnswerIndex: Int,
    val keyFact: String = ""
)