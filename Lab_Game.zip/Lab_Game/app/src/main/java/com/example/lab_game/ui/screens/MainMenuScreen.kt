package com.example.lab_game.ui.screens


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun MainMenuScreen(navController: NavController) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFEADABA)) // warm earth tone
    ) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Tunisia Heritage Quest", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(24.dp))
            Button(onClick = { navController.navigate("category") }) { Text("Play") }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { /* Add About or Settings if needed */ }) { Text("About") }
        }
    }
}