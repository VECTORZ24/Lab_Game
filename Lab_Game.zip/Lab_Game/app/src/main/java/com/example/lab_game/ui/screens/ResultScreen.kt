package com.example.lab_game.ui.screens


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.lab_game.viewmodel.QuizViewModel

@Composable
fun ResultsScreen(navController: NavController, quizViewModel: QuizViewModel = viewModel()) {
    val score = quizViewModel.score.value
    val total = quizViewModel.questions.size
    val percent = score * 100 / total
    val message = when {
        percent == 100 -> "Excellent! You are a Roman heritage master!"
        percent >= 70  -> "Great job! You know your monuments."
        percent >= 50  -> "Good attempt. Keep learning!"
        else -> "Try again, discover more about Tunisia's Roman sites."
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFEADABA))
    ) {
        Column(modifier = Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Quiz Results", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Text("Score: $score/$total ($percent%)", fontSize = 22.sp)
            Spacer(Modifier.height(16.dp))
            Text(message, fontSize = 18.sp)
            Spacer(Modifier.height(30.dp))
            Button(onClick = {
                quizViewModel.reset()
                navController.navigate("menu")
            }) {
                Text("Main Menu")
            }
        }
    }
}