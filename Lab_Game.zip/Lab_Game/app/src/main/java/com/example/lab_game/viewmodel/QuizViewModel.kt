package com.example.lab_game.viewmodel



import androidx.lifecycle.ViewModel
import androidx.compose.runtime.mutableStateOf
import com.example.lab_game.data.QuizQuestion
import com.example.lab_game.data.romanQuestions

class QuizViewModel : ViewModel() {
    var currentQuestionIndex = mutableStateOf(0)
    var score = mutableStateOf(0)
    var answered = mutableStateOf(false)
    var selectedAnswer = mutableStateOf(-1)

    val questions: List<QuizQuestion> = romanQuestions.shuffled()

    fun nextQuestion() {
        if (currentQuestionIndex.value < questions.size - 1) {
            currentQuestionIndex.value++
            answered.value = false
            selectedAnswer.value = -1
        }
    }

    fun answerQuestion(index: Int) {
        selectedAnswer.value = index
        answered.value = true
        if (index == questions[currentQuestionIndex.value].answerIndex) {
            score.value += 1
        }
    }

    fun reset() {
        currentQuestionIndex.value = 0
        score.value = 0
        answered.value = false
        selectedAnswer.value = -1
    }

    fun isLastQuestion(): Boolean = currentQuestionIndex.value == questions.size - 1
}