package com.example.lab_game.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.lab_game.viewmodel.QuizViewModel
import kotlinx.coroutines.delay

@Composable
fun QuizScreen(navController: NavController, quizViewModel: QuizViewModel = viewModel()) {
    val question = quizViewModel.questions[quizViewModel.currentQuestionIndex.value]
    val totalQuestions = quizViewModel.questions.size
    var timeLeft by remember { mutableStateOf(15) }
    val answered = quizViewModel.answered.value

    LaunchedEffect(key1 = quizViewModel.currentQuestionIndex.value) {
        timeLeft = 15
        if (!answered) {
            repeat(15) {
                delay(1000L)
                if (!quizViewModel.answered.value && timeLeft > 0) timeLeft--
                if (timeLeft == 0 && !quizViewModel.answered.value) {
                    quizViewModel.answerQuestion(-1)
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFEADABA))
            .padding(16.dp)
    ) {
        Text("Question ${quizViewModel.currentQuestionIndex.value + 1} of $totalQuestions", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(progress = (quizViewModel.currentQuestionIndex.value + 1) / totalQuestions.toFloat())
        Spacer(Modifier.height(10.dp))
        Text("Time: $timeLeft s", color = if (timeLeft <= 5) Color.Red else Color.Black, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Image(
            painter = painterResource(question.imageRes),
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text(question.question, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(16.dp))

        question.options.forEachIndexed { idx, opt ->
            Button(
                onClick = { if (!answered) quizViewModel.answerQuestion(idx) },
                colors = ButtonDefaults.buttonColors(
                    backgroundColor = when {
                        answered && idx == question.answerIndex -> Color.Green
                        answered && idx == quizViewModel.selectedAnswer.value && idx != question.answerIndex -> Color.Red
                        else -> Color.White
                    }
                ),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                enabled = !answered
            ) {
                Text(opt, color = Color.Black)
            }
        }

        if (answered) {
            Spacer(Modifier.height(14.dp))
            Text(
                text = "Fact: ${question.keyFact}",
                color = Color(0xFF14396E),
                fontSize = 16.sp,
                modifier = Modifier.padding(8.dp)
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    if (quizViewModel.isLastQuestion()) {
                        navController.navigate("results")
                    } else {
                        quizViewModel.nextQuestion()
                    }
                },
                modifier = Modifier.align(Alignment.End)
            ) {
                Text(if (quizViewModel.isLastQuestion()) "Finish" else "Next")
            }
        }
    }
}